
  // const ctx = document.getElementById('doughnutChart').getContext('2d');
  // const doughnutChart = new Chart(ctx, {
  //   type: 'doughnut',
  //   data: {
  //     labels: ['Cured', 'Lost to Follow-up', 'Failed', 'Died'],
  //     datasets: [{
  //       label: 'Total',
  //       data: [
  //         $totalCured,
  //         $totalLost,
  //         $totalFailed, 
  //         $totalDied
  //       ], 
  //       backgroundColor: [
  //         'rgba(9, 172, 117, 0.7)',
  //         'rgba(75, 192, 192, 0.7)',
  //         'rgba(255, 206, 86, 0.7)',
  //         'rgba(255, 99, 132, 0.7)'
          
  //       ],
  //       borderColor: [
  //         'rgba(9, 172, 117, 1)',
  //         'rgba(75, 192, 192, 1)',
  //         'rgba(255, 206, 86, 1)',
  //         'rgba(255, 99, 132, 1)'
  //       ],
  //       borderWidth: 1
  //     }]
  //   },
  //   options: {
  //     responsive: true,
  //     plugins: {
  //       legend: {
  //         position: 'bottom'
  //       },
  //       title: {
  //         display: false
  //       }
  //     }
  //   }
  // });


//   <div class="card mt-4">
//   <div class="card-body">
//     <h5 class="card-title">Patient Care Result Summary</h5>
//     <canvas id="doughnutChart" class="doughnut-chart"></canvas>
//   </div>
// </div>

{/* <script>
  const ctx = document.getElementById('doughnutChart').getContext('2d');
  const doughnutChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Cured', 'Lost to Follow-up', 'Failed', 'Died'],
      datasets: [{
        label: 'Total',
        data: [
          {{ $totalCured }},
          {{ $totalLost }},
          {{ $totalFailed }},
          {{ $totalDied }}
        ],
        backgroundColor: [
          'rgba(9, 172, 117, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(255, 99, 132, 0.7)'
        ],
        borderColor: [
          'rgba(9, 172, 117, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(255, 99, 132, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom'
        },
        title: {
          display: false
        }
      }
    }
  });
</script> */}
// dapat sulod ni sa blade

/* .doughnut-chart {
      max-width: 300px;
      max-height: 300px;
      margin: 0 auto;
      display: block;
    } */
  //  css