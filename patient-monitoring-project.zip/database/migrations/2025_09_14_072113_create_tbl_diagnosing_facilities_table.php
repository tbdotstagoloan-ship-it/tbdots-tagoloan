<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tbl_diagnosing_facilities', function (Blueprint $table) {
            $table->id();
            $table->string('fac_name');
            $table->string('fac_ntp_code');
            $table->string('fac_province');
            $table->string('fac_region');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tbl_diagnosing_facilities');
    }
};
