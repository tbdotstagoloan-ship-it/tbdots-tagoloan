<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>TB DOTS - Add New Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
    <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
  </head>

  <body>
    <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('admin/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form/page1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patient')); ?>" class="nav-link">Patient List</a>
          </li>
          <li>
            <a href="<?php echo e(url('patientProfile')); ?>" class="nav-link">Patient Profile</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('medicalInformation')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Medical Information
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('adherenceTrackingData')); ?>">
           <span class="material-symbols-rounded">monitoring</span>
          Adherence Track Data
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Patient Health</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Adherence Report</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Treatment Logs</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

    <div class="main-content">
      <h3 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600;">
        Adherence Tracking Data
      </h3>
      
      <div class="card inventory-card shadow-sm border-0">
        <div class="card-body p-0">
          <div class="table-responsive">
                
                <form action="" method="post" class="p-2">

                  <h5 class="mb-4">Number of Taken & Missed Doses</h5>
                  <div class="row">
                    <div class="col-md-3">
                      <label for="">Patient's Full Name</label>
                      <input type="text" name="" class="form-control" placeholder="Patient's Full Name" required>
                    </div>
                    <div class="col-md-3">
                      <label for="">Age</label>
                      <input type="text" name="age" class="form-control" placeholder="Age" required>
                    </div>
                    <div class="col-md-3">
                      <label for="address">Address</label>
                      <input type="text" name="address" class="form-control" placeholder="Address" required>
                    </div>
                    <div class="col-md-3">
                      <label for="sex">Sex</label>
                       <select name="sex" class="form-control form-select" required>
                        <option value="" disabled selected>Please Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                       </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-6">
                      <label for="">Number of Taken Doses</label>
                      <input type="text" name="" class="form-control" placeholder="Number of Taken Doses" required>
                    </div>
                    <div class="col-md-6">
                      <label for="">Number of Missed Doses</label>
                      <input type="text" name="" class="form-control" placeholder="Number of Missed Doses" required>
                    </div>
                  </div>

                <!-- <div class="d-flex justify-content-center"> -->
                  <div class="float-end">
                   <button type="submit" class="btn add-product-btn btn-success"><i class="fas fa-save me-2"></i>Save</button>
                </div>
                </form>
  
                </div>
              </div>
            </div>
          </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/admin/adherenceTrackingData.blade.php ENDPATH**/ ?>