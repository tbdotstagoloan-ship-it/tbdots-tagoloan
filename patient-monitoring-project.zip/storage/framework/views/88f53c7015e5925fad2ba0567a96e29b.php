<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>TB DOTS - Add New Patient</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
  <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
</head>

<body>
  <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('admin/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patient')); ?>" class="nav-link">Patient List</a>
          </li>
          <li>
            <a href="<?php echo e(url('patientProfile')); ?>" class="nav-link">Patient Profile</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('medicalInformation')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Medical Information
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('adherenceTrackingData')); ?>">
           <span class="material-symbols-rounded">monitoring</span>
          Adherence Track Data
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Patient Health</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Adherence Report</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Treatment Logs</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

  <div class="main-content">
    <h4 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600">
      National TB Control Program
    </h4>


    <div class="card inventory-card shadow-sm border-0">
      <div class="card-body p-0">
        <div class="table-responsive">

          <form action="" method="post" class="p-2">

            <!-- <h5 class="mb-4">II. Treatment</h5>
            <div class="row mb-2">
                    <div class="col-md-3">
                      <label for="diagnosing_facility">Name of Diagnosing Facility</label>
                      <input type="text" name="diagnosing_facility" class="form-control" placeholder="Diagnosing Facility" required>
                    </div>
                    <div class="col-md-3">
                      <label for="ntp_code">NTP Facility Code</label>
                      <input type="text" name="ntp_code" class="form-control" placeholder="NTP Facility Code" required>
                    </div>
                    <div class="col-md-3">
                      <label for="province">Province / HUC</label>
                      <input type="text" name="province" class="form-control" placeholder="Province / HUC" required>
                    </div>
                    <div class="col-md-3">
                      <label for="region">Region</label>
                       <select name="region" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Region I - Ilocos Region">Region I - Ilocos Region</option>
                        <option value="Region II - Cagayan Valley">Region II - Cagayan Valley</option>
                        <option value="Region III - Central Luzon">Region III - Central Luzon</option>
                        <option value="Region IV - CALABARZON MIMAROPA Region">Region IV - CALABARZON</option>
                        <option value="Region V - Bicol Region">Region V - Bicol Region</option>
                        <option value="Region VI - Western Visayas">Region VI - Western Visayas</option>
                        <option value="Region VII - Central Visayas">Region VII - Central Visayas</option>
                        <option value="Region VIII - Eastern Visayas">Region VIII - Eastern Visayas</option>
                        <option value="Region IX - Zamboanga Peninsula">Region IX - Zamboanga Peninsula</option>
                        <option value="Region X - Northen Mindanao">Region X - Northen Mindanao</option>
                        <option value="Region XI - Davao Region">Region XI - Davao Region</option>
                        <option value="Region XII - SOCCSKSARGEN">Region XII - SOCCSKSARGEN</option>
                        <option value="Region XIII - Caraga">Region XIII - Caraga</option>
                       </select>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">A. Baseline Information</h5>
                  <div class="row align-items-center mb-3">
                    <div class="col-md-6">
                      <label for="ho_tbtreatment" id="ho_tbtreatment_label">History of TB Treatment</label>
                    </div>
                    <div class="col-md-6 d-flex align-items-center mt-3 mt-md-0 justify-content-md-end">
                      <input class="form-check-input me-2" type="checkbox" id="ho_tbtreatment" name="ho_tbtreatment_none" onchange="toggleTreatmentFieldsCheckbox(this)">
                      <label class="form-check-label mb-0" for="ho_tbtreatment">No history of TB treatment</label>
                    </div>
                  </div>

                  <div id="treatmentDetails">
                    <div class="row mb-2">
                      <div class="col-md-3">
                        <label for="dtx_started">Date Tx Started</label>
                        <input type="date" id="dtx_started" name="dtx_started" class="form-control" placeholder="dd/mm/yyyy" required>
                      </div>
                      <div class="col-md-3">
                        <label for="notu">Name of Treatment Unit</label>
                        <input type="text" id="notu" name="notu" class="form-control" placeholder="Name of Treatment Unit" required>
                      </div>
                      <div class="col-md-3">
                        <label for="treatment_regimen">Treatment Regimen</label>
                        <input type="text" id="treatment_regimen" name="treatment_regimen" class="form-control" placeholder="Drug & Duration" required>
                      </div>
                      <div class="col-md-3">
                        <label for="outcome">Outcome</label>
                        <input type="text" id="outcome" name="outcome" class="form-control" placeholder="Outcome" required>
                      </div>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-md-3">
                      <label for="hiv_info">HIV Information</label>
                      <select name="hiv_info" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Know PLHIV Prior to Start of Tx">Know PLHIV Prior to Start of Tx</option>
                        <option value="Not Eligible for Testing">Not Eligible for Testing</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for="hiv_td">HIV Test Date</label>
                      <input type="date" name="hiv_td" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                      <label for="ctd">Confirmatory Test Date</label>
                      <input type="date" name="ctd" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                      <label for="result">Result</label>
                      <select name="result" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="P">P</option>
                        <option value="N">N</option>
                        <option value="Undetermined">Undetermined</option>
                      </select>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-3">
                      <label for="soart">Started on ART?</label>
                      <select name="soart" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for="socpt">Started on CPT?</label>
                      <select name="socpt" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for="height">Height</label>
                      <input type="text" name="height" class="form-control" placeholder="Height" required>
                    </div>
                    <div class="col-md-3">
                      <label for="weight">Weight</label>
                      <input type="text" name="weight" class="form-control" placeholder="Weight" required>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <label for="ovs">Other Vital Signs or Treatment Considerations</label>
                      <input type="text" name="ovs" class="form-control" placeholder="Other Vital Signs or Treatment Considerations" required>
                    </div>
                    <div class="col-md-6">
                      <label for="emergency">Person to Notify in case of Emergency</label>
                      <input type="text" name="emergency" class="form-control" placeholder="Person to Notify in case of Emergency" required>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-3">
                      <label for="relationship">Relationship</label>
                      <input type="text" name="relationship" class="form-control" placeholder="Relationship" required>
                    </div>
                    <div class="col-md-3">
                      <label for="contact_info">Contact Information</label>
                      <input type="text" name="contact_info" class="form-control" placeholder="Contact Information" required>
                    </div>
                    <div class="col-md-3">
                      <label for="diabetes_screening">Diabetes Screening</label>
                      <select name="diabetes_screening" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Know Diabetic">Know Diabetic</option>
                        <option value="Not Eligible">Not Eligible</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for="4ps_beneficiary">4Ps Beneficiary?</label>
                      <select name="4ps_beneficiary" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>
                    </div>
                  </div>

                  <div class="row mb-2">
                    <div class="col-md-3">
                      <label for="fbs_screening">FBS Screening</label>
                      <input type="text" name="fbs_screening" class="form-control" placeholder="mg/dl" required>
                    </div>
                    <div class="col-md-3">
                      <label for="date_tested">Date Tested</label>
                      <input type="date" name="date_tested" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                      <label for="occupation">Occupation</label>
                      <input type="text" name="occupation" class="form-control" placeholder="Occupation" required>
                    </div>
                  </div>

                  <hr>
                  <div class="row align-items-center mb-3">
                  <div class="col-md-6">
                    <label for="co_morbidities" id="co_morbidities">Co-morbidities</label>
                  </div>
                  <div class="col-md-6 d-flex align-items-center mt-3 mt-md-0 justify-content-md-end">
                    <input type="checkbox" id="no_comorbidities" class="me-2" onchange="toggleComorbidities(this)">
                    <label for="no_comorbidities" class="mb-0">No Known</label>
                  </div>
                </div>

                <div id="comorbidityDetails">
                  <div class="row mb-2">
                    <div class="col-md-3">
                      <label for="date_diagnosed">Date Diagnosed</label>
                      <input type="date" id="date_diagnosed" name="date_diagnosed" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                      <label for="type">Type</label>
                      <select id="type" name="type" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Diabetes Mellitus">Diabetes Mellitus</option>
                        <option value="Mental Illness">Mental Illness</option>
                        <option value="Substance Abuse">Substance Abuse</option>
                        <option value="Liver Disease">Liver Disease</option>
                        <option value="Renal Disease">Renal Disease</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for="other">Other</label>
                      <input type="text" id="other" name="other" class="form-control" placeholder="Other Type" required>
                    </div>
                    <div class="col-md-3">
                      <label for="treatment">Treatment</label>
                      <input type="text" id="treatment" name="treatment" class="form-control" placeholder="Treatment" required>
                    </div>
                  </div>
                </div>

                  <hr>
                  <h5 class="mb-4">B. Treatment Regimen</h5>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label for="regimen_type">Regimen Type at Start of Treatment</label>
                      <select name="regimen_type" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Regimen 1 - 2HRZE/4HR">Regimen 1 - 2HRZE/4HR</option>
                        <option value="Regimen 2 - 2HRZE/10HR">Regimen 2 - 2HRZE/10HR</option>
                      </select>
                    </div>
                    <div class="col-md-4">
                      <label for="treatment_startdate">Treatment Start Date</label>
                      <input type="date" name="treatment_startdate" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="treatment_enddate">Regimen Type at End of Treatment</label>
                      <input type="date" name="treatment_enddate" class="form-control" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">C. Treatment Outcome</h5>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label for="outcome">Outcome</label>
                      <select name="outcome" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Cured">Cured</option>
                        <option value="Treatment Completed">Treatment Completed</option>
                        <option value="Failed">Failed</option>
                        <option value="Lost to Follow-up">Lost to Follow-up</option>
                        <option value="Died">Died</option>
                      </select>
                    </div>
                    <div class="col-md-4">
                      <label for="doo">Date of Outcome</label>
                      <input type="date" name="doo" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="reason">Reason</label>
                      <input type="text" name="reason" class="form-control" placeholder="If Failed, LTFU, or Died" required>
                    </div>
                  </div> -->

                  <div class="row mb-2">
                    <div class="col-md-3">
                        <label for="date_start">Date Start</label>
                        <input type="date" name="date_start" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="drug">Drug</label>
                        <select name="drug" class="form-control form-select" required>
                            <option value="" disabled selected>Select</option>
                            <option value="4FDC">4FDC</option>
                            <option value="2FDC">2FDC</option>
                            <option value="H">H</option>
                            <option value="R">R</option>
                            <option value="Z">Z</option>
                            <option value="E">E</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="strength">Strength</label>
                        <input type="text" name="strength" class="form-control" placeholder="Strength" required>
                    </div>
                    <div class="col-md-3">
                        <label for="unit">Unit</label>
                        <input type="text" name="unit" class="form-control" placeholder="Unit" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">E. Serious Adverse Events and AEs of Special Interest</h5>
                   <div class="row mb-2">
                    <div class="col-md-3">
                      <label for="doae">Date of AE</label>
                      <input type="date" name="doae" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                      <label for="specific_ae">Specific AE</label>
                      <input type="text" name="specific_ae" class="form-control" placeholder="Specific AE" required>
                    </div>
                    <div class="col-md-3">
                      <label for="drt_fda">Date Reported to FDA</label>
                      <input type="date" name="drt_fda" class="form-control" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">D. Administration of Drugs</h5>
                  <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="lot">Location of Treatment</label>
                        <select name="lot" class="form-control form-select" required>
                            <option value="" disabled selected>Select</option>
                            <option value="Facility-based">Falicity-based</option>
                            <option value="Community-based">Community-based</option>
                            <option value="Home-based">Home-based</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Name" required>
                    </div>
                    <div class="col-md-3">
                        <label for="designation">Designation</label>
                        <input type="text" name="designation" class="form-control" placeholder="Designation" required>
                    </div>
                    <div class="col-md-3">
                        <label for="to_txs">Type of Tx Supporter</label>
                        <select name="to_txsupporter" class="form-control form-select" required>
                            <option value="" disabled selected>Select</option>
                            <option value="Falicity HCW">Falicity HCW</option>
                            <option value="Community HCW">Community HCW</option>
                            <option value="Family">Family</option>
                            <option value="Lay Volunteer">Lay Volunteer</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="tsci">Tx Supporter Contact Information</label>
                        <input type="text" name="tsci" class="form-control" placeholder="Tx Supporter Contact Information" required>
                    </div>
                    <div class="col-md-4">
                        <label for="sot">Schedule of Treatment</label>
                        <input type="text" name="sot" class="form-control" placeholder="Schedule of Treatment" required>
                    </div>
                    <div class="col-md-4">
                        <label for="nodat">Name of DAT/s Used</label>
                        <input type="text" name="nodat" class="form-control" placeholder="Name of DAT/s Used" required>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="ipsd">Intensive Phase Start Date</label>
                        <input type="date" name="ipsd" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="ied">IP End Date</label>
                        <input type="date" name="ied" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="cpsd">Continuation Phase Start Date</label>
                        <input type="date" name="cpsd" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="cped">CP End Date</label>
                        <input type="date" name="cped" class="form-control" required>
                    </div>
                  </div>
                  
              <div class="float-end">
            <button type="submit" class="btn add-product-btn btn-success">Save Data</button>
          </div>

          </form>

        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
  <!-- <script src="<?php echo e(url('assets/js/checkbox.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/checkbox1.js')); ?>"></script> -->

</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/admin/form3.blade.php ENDPATH**/ ?>