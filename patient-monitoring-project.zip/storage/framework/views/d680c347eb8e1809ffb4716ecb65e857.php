<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>TB DOTS - Add New Patient</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>" />
  <link rel="icon" href="<?php echo e(url('assets/img/lungs.png')); ?>">
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" alt="TB DOTS Logo" />
      </div>
      <div class="sidebar-brand">
        <h2>TB DOTS</h2>
        <p>Monitoring System</p>
      </div>
    </div>

    <ul class="sidebar-menu" id="sidebarAccordion">
      <li class="menu-item" data-tooltip="Dashboard">
        <a href="<?php echo e(url('admin/dashboard')); ?>" class="active">
          <span class="material-symbols-rounded">grid_view</span>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <!-- <li class="menu-item" data-tooltip="Diagnosis">
        <a href="<?php echo e(url('diagnosis')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          <span class="menu-text">Diagnosis</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Notification">
        <a href="<?php echo e(url('notification')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          <span class="menu-text">Notification</span>
        </a>
      </li> -->

      <li class="nav-item menu-item" data-tooltip="Patient">
        <a href="#" class="nav-link d-flex align-items-center patient-toggle">
          <span class="material-symbols-rounded">patient_list</span>
          <span class="menu-text">Patient</span>
          <i class="fas fa-chevron-left toggle-arrow"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a class="nav-link" href="<?php echo e(url('form/page1')); ?>">Add Patient</a></li>
          <li><a class="nav-link" href="<?php echo e(url('patient')); ?>">Patient List</a></li>
        </ul>
      </li>

      <!-- <li class="menu-item" data-tooltip="Treatment">
        <a href="<?php echo e(url('treatment')); ?>">
          <span class="material-symbols-rounded">medical_services</span>
          <span class="menu-text">Treatment</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Treatment Outcome">
        <a href="<?php echo e(url('treatmentOutcome')); ?>">
          <span class="material-symbols-rounded">health_metrics</span>
          <span class="menu-text">Treatment Outcome</span>
        </a>
      </li> -->

      <li class="menu-tem" data-tooltip="Patient Summary Report">
        <a href="<?php echo e(url('patientSummary')); ?>">
          <span class="material-symbols-rounded">clinical_notes</span>
          <span class="menu-text">Patient Summary Report</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Generate Reports">
        <a href="#" class="nav-link d-flex align-items-center reports-toggle">
          <span class="material-symbols-rounded">download</span>
          <span class="menu-text">Generate Reports</span>
          <i class="fas fa-chevron-left toggle-arrow rotate-icon"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a href="<?php echo e(url('feedback')); ?>" class="nav-link">Patient Feedback</a></li>
          <li><a href="<?php echo e(url('diagClassification')); ?>" class="nav-link">Patient Diagnosis</a></li>
          <li><a href="<?php echo e(url('notificationLog')); ?>" class="nav-link">Notification Log</a></li>
          <li><a href="<?php echo e(url('ongoingTreatments')); ?>" class="nav-link">Ongoing Treatment</a></li>
          <li><a href="<?php echo e(url('curedPatients')); ?>" class="nav-link">Cured Patients</a></li>
          <li><a href="<?php echo e(url('ltfuPatients')); ?>" class="nav-link">Lost to Follow-up</a></li>
          <li><a href="<?php echo e(url('failedPatients')); ?>" class="nav-link">Failed Treatments</a></li>
          <li><a href="<?php echo e(url('expiredPatients')); ?>" class="nav-link">Expired Patients</a></li>
          <li><a href="<?php echo e(url('intensiveTreatment')); ?>" class="nav-link">Intensive Treatment</a></li>
          <li><a href="<?php echo e(url('maintenanceTreatment')); ?>" class="nav-link">Maintenance Treatment</a></li>
          <li><a href="<?php echo e(url('barangayCases')); ?>" class="nav-link">Barangay Cases</a></li>
          <li><a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Underage Patients</a></li>
          <li><a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Sputum Log</a></li>
          <li><a href="<?php echo e(url('closeContact')); ?>" class="nav-link">Close Contact</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Settings">
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span>
          <span class="menu-text">Settings</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Logout">
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            <span class="menu-text">Logout</span>
          </button>
        </form>
      </li>

    </ul>
  </div>

  <div class="header" id="header">
    <div class="header-left">
      <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>

    <!-- <div class="header-right">
      <div class="user-profile">
        <div class="user-avatar">
          <i class="fas fa-user"></i>
        </div>
        <div class="user-info">
          <span>Admin</span>
        </div>
      </div>
    </div> -->

  </div>

  <div class="main-content py-4" id="mainContent">
    <h4 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600">
      National TB Control Program
    </h4>


    <div class="card inventory-card shadow-sm border-0">
      <div class="card-body p-0">
        <div class="table-responsive">

          <form action="" method="post" class="p-2">

                  <h5 class="mb-4">F. Patient Progress Report Form</h5>
                  <div class="row mb-2">
                    <div class="col-md-3">
                        <label for="date">Date</label>
                        <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="problem">Problem</label>
                        <input type="text" name="problem" class="form-control" placeholder="AE, reason of absence" required>
                    </div>
                    <div class="col-md-3">
                        <label for="action_taken">Action Taken</label>
                        <input type="text" name="action_taken" class="form-control" placeholder="Action taken" required>
                    </div>
                    <div class="col-md-3">
                        <label for="plan">Plan</label>
                        <input type="text" name="plan" class="form-control" placeholder="Plan" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">G. Close Contacts</h5>
                  <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Name" required>
                    </div>
                    <div class="col-md-3">
                        <label for="age">Age</label>
                        <input type="text" name="age" class="form-control" placeholder="Age" required>
                    </div>
                    <div class="col-md-3">
                        <label for="sex">Sex</label>
                        <select name="sex" class="form-control form-select" required>
                            <option value="" disabled selected>Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="relationship">Relationship</label>
                        <input type="text" name="relationship" class="form-control" placeholder="Relationship" required>
                    </div>
                  </div>

                  <div class="row mb-2">
                    <div class="col-md-3">
                        <label for="initial_screening">Initial Screening</label>
                        <input type="date" name="initial_screening" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="follow_up">Ff-up</label>
                        <input type="date" name="follow_up" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="remarks">Remarks</label>
                        <input type="text" name="remarks" class="form-control" placeholder="TB/ TPT Case Number" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">H. Sputum Monitoring</h5>
                  <div class="row mb-2">
                    <div class="col-md-4">
                        <label for="date_collected">Date Collected</label>
                        <input type="date" name="date_collected" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="smear_microscopy">Smear Microscopy/ TB LAMP</label>
                        <input type="text" name="smear_microscopy" class="form-control" placeholder="Smear Microscopy/ TB LAMP" required>
                    </div>
                    <div class="col-md-4">
                        <label for="xpert_result">Xpert MTB/RIF</label>
                        <input type="text" name="xpert_result" class="form-control" placeholder="Xpert MTB/RIF" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">I. Chest X-ray</h5>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label for="cxr_date_examined">Date Examined</label>
                      <input type="date" name="cxr_date_examined" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="cxr_impression">Impression/ Comparative Reading</label>
                      <select name="cxr_impression" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Normal">Normal</option>
                        <option value="Abnormal suggestive of TB">Abnormal suggestive of TB</option>
                        <option value="Abnormal not suggestive of TB">Abnormal not suggestive of TB</option>
                      </select>
                    </div>
                    <div class="col-md-4">
                      <label for="descriptive_comments">Descriptive Comments</label>
                      <input type="text" name="descriptive_comments" class="form-control" placeholder="Descriptive Comments" required>
                    </div>
                  </div>

                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label for="date_examined"></label>
                      <input type="date" name="date_examined" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="impression"></label>
                      <select name="impression" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Normal">Improved</option>
                        <option value="Abnormal suggestive of TB">Stable/Unchanged</option>
                        <option value="Abnormal not suggestive of TB">Worsened</option>
                      </select>
                    </div>
                    <div class="col-md-4">
                      <label for="descriptive_comments"></label>
                      <input type="text" name="descriptive_comments" class="form-control" placeholder="Descriptive Comments" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">J. Post Treatment Follow-up</h5>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label for="months_after_tx">Mo. After Tx</label>
                      <input type="text" name="months_after_tx" class="form-control" placeholder="PT" required>
                    </div>
                    <div class="col-md-4">
                      <label for="date">Date</label>
                      <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="cxr_findings">CXR Findings</label>
                      <input type="text" name="cxr_findings" class="form-control" placeholder="CXR Findings" required>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label for="smear_xpert_result">Smear/ Xpert</label>
                      <input type="text" name="smear_xpert_result" class="form-control" placeholder="Smear/ Xpert" required>
                    </div>
                    <div class="col-md-4">
                      <label for="tbc_dst_result">TBC & DST</label>
                      <input type="text" name="tbc_dst_result" class="form-control" placeholder="TBC & DST" required>
                    </div>
                  </div>
                  
              <div class="float-end">
                <button type="submit" class="btn add-patient-btn btn-success">Add New Patient</button>
              </div>

          </form>

              <div>
                <a href="<?php echo e(url('form/page3')); ?>" class="btn btn-sm prev-btn btn-secondary" style="margin-left: 10px"><</a>
                <a href="#" class="btn btn-sm next-btn btn-secondary">></a>
              </div>

        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/sidebarToggle.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/rotate-icon.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/form/page4.blade.php ENDPATH**/ ?>