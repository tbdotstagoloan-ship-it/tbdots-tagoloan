<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>TB DOTS - Treatment</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="icon" href="<?php echo e(url('assets/img/lungs.png')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">
        <img src="<?php echo e(url('assets/img/lungs.png')); ?>" alt="TB DOTS Logo" />
      </div>
      <div class="sidebar-brand">
        <h2>TB DOTS</h2>
        <p>RHU, Tagoloan</p>
      </div>
    </div>

    <ul class="sidebar-menu" id="sidebarAccordion">
      <li class="menu-item" data-tooltip="Dashboard">
        <a href="<?php echo e(url('admin/dashboard')); ?>" class="active">
          <span class="material-symbols-rounded">grid_view</span>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Patient">
        <a href="#" class="nav-link d-flex align-items-center patient-toggle">
          <span class="material-symbols-rounded">group</span>
          <span class="menu-text">Patient</span>
          <i class="fas fa-chevron-left toggle-arrow"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a class="nav-link" href="<?php echo e(url('form/page1')); ?>">Add Patient</a></li>
          <li><a class="nav-link" href="<?php echo e(url('patient')); ?>">Patient List</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Diagnosis">
        <a href="<?php echo e(url('diagnosis')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          <span class="menu-text">Diagnosis</span>
        </a>
      </li>
      
      <li class="menu-item" data-tooltip="Treatment">
        <a href="<?php echo e(url('treatment')); ?>">
          <span class="material-symbols-rounded">medical_services</span>
          <span class="menu-text">Treatment</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Treatment Outcome">
        <a href="<?php echo e(url('treatmentOutcome')); ?>">
          <span class="material-symbols-rounded">health_metrics</span>
          <span class="menu-text">Outcome</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Notification">
        <a href="<?php echo e(url('notification')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          <span class="menu-text">Notification</span>
        </a>
      </li>

      <li class="menu-tem" data-tooltip="Patient Summary Report">
        <a href="<?php echo e(url('patientSummary')); ?>">
          <span class="material-symbols-rounded">clinical_notes</span>
          <span class="menu-text">Patient Summary Report</span>
        </a>
      </li>

      <!-- <li class="nav-item menu-item" data-tooltip="Generate Reports">
        <a href="#" class="nav-link d-flex align-items-center reports-toggle">
          <span class="material-symbols-rounded">download</span>
          <span class="menu-text">Generate Reports</span>
          <i class="fas fa-chevron-left toggle-arrow rotate-icon"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a href="<?php echo e(url('feedback')); ?>" class="nav-link">Patient Feedback</a></li>
          <li><a href="<?php echo e(url('diagClassification')); ?>" class="nav-link">Patient Diagnosis</a></li>
          <li><a href="<?php echo e(url('notificationLog')); ?>" class="nav-link">Notification Log</a></li>
          <li><a href="<?php echo e(url('ongoingTreatments')); ?>" class="nav-link">Ongoing Treatment</a></li>
          <li><a href="<?php echo e(url('curedPatients')); ?>" class="nav-link">Cured Patients</a></li>
          <li><a href="<?php echo e(url('ltfuPatients')); ?>" class="nav-link">Lost to Follow-up</a></li>
          <li><a href="<?php echo e(url('failedPatients')); ?>" class="nav-link">Failed Treatments</a></li>
          <li><a href="<?php echo e(url('expiredPatients')); ?>" class="nav-link">Expired Patients</a></li>
          <li><a href="<?php echo e(url('intensiveTreatment')); ?>" class="nav-link">Intensive Treatment</a></li>
          <li><a href="<?php echo e(url('maintenanceTreatment')); ?>" class="nav-link">Maintenance Treatment</a></li>
          <li><a href="<?php echo e(url('barangayCases')); ?>" class="nav-link">Barangay Cases</a></li>
          <li><a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Underage Patients</a></li>
          <li><a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Sputum Log</a></li>
          <li><a href="<?php echo e(url('closeContact')); ?>" class="nav-link">Close Contact</a></li>
        </ul>
      </li> -->

      <li class="menu-item" data-tooltip="Settings">
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span>
          <span class="menu-text">Settings</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Logout">
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            <span class="menu-text">Logout</span>
          </button>
        </form>
      </li>

    </ul>
  </div>

  <div class="header" id="header">
    <div class="header-left">
      <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>

    <!-- <div class="header-right">
      <div class="user-profile">
        <div class="user-avatar">
          <i class="fas fa-user"></i>
        </div>
        <div class="user-info">
          <span>Admin</span>
        </div>
      </div>
    </div> -->
    
  </div>

  <div class="main-content py-4" id="mainContent">
    <h3>Treatment</h3>

    

  </div>



  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="<?php echo e(url('assets/js/sidebarToggle.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/rotate-icon.js')); ?>"></script>

  <!-- <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script> -->
  <!-- <script src="<?php echo e(url('assets/js/script.js')); ?>"></script> -->

</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/treatment.blade.php ENDPATH**/ ?>