<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>TB DOTS - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="icon" href="<?php echo e(url('assets/img/lungs.png')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" alt="TB DOTS Logo" />
      </div>
      <div class="sidebar-brand">
        <h2>TB DOTS</h2>
        <p>Monitoring System</p>
      </div>
    </div>

    <ul class="sidebar-menu" id="sidebarAccordion">
      <li class="menu-item" data-tooltip="Dashboard">
        <a href="<?php echo e(url('admin/dashboard')); ?>" class="active">
          <span class="material-symbols-rounded">grid_view</span>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Diagnosis">
        <a href="<?php echo e(url('diagnosis')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          <span class="menu-text">Diagnosis</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Notification">
        <a href="<?php echo e(url('notification')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          <span class="menu-text">Notification</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Patient">
        <a href="#" class="nav-link d-flex align-items-center patient-toggle">
          <span class="material-symbols-rounded">group</span>
          <span class="menu-text">Patient</span>
          <i class="fas fa-chevron-left toggle-arrow"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a class="nav-link" href="<?php echo e(url('form/page1')); ?>">Add Patient</a></li>
          <li><a class="nav-link" href="<?php echo e(url('patient')); ?>">Patient List</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Treatment">
        <a href="<?php echo e(url('treatment')); ?>">
          <span class="material-symbols-rounded">medical_services</span>
          <span class="menu-text">Treatment</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Treatment Outcome">
        <a href="<?php echo e(url('treatmentOutcome')); ?>">
          <span class="material-symbols-rounded">health_metrics</span>
          <span class="menu-text">Treatment Outcome</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Generate Reports">
        <a href="#" class="nav-link d-flex align-items-center reports-toggle">
          <span class="material-symbols-rounded">download</span>
          <span class="menu-text">Generate Reports</span>
          <i class="fas fa-chevron-left toggle-arrow rotate-icon"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a href="<?php echo e(url('feedback')); ?>" class="nav-link">Patient Feedback</a></li>
          <li><a href="<?php echo e(url('diagClassification')); ?>" class="nav-link">Patient Diagnosis</a></li>
          <li><a href="<?php echo e(url('notificationLog')); ?>" class="nav-link">Notification Log</a></li>
          <li><a href="<?php echo e(url('ongoingTreatments')); ?>" class="nav-link">Ongoing Treatment</a></li>
          <li><a href="<?php echo e(url('curedPatients')); ?>" class="nav-link">Cured Patients</a></li>
          <li><a href="<?php echo e(url('ltfuPatients')); ?>" class="nav-link">Lost to Follow-up</a></li>
          <li><a href="<?php echo e(url('failedPatients')); ?>" class="nav-link">Failed Treatments</a></li>
          <li><a href="<?php echo e(url('expiredPatients')); ?>" class="nav-link">Expired Patients</a></li>
          <li><a href="<?php echo e(url('intensiveTreatment')); ?>" class="nav-link">Intensive Treatment</a></li>
          <li><a href="<?php echo e(url('maintenanceTreatment')); ?>" class="nav-link">Maintenance Treatment</a></li>
          <li><a href="<?php echo e(url('barangayCases')); ?>" class="nav-link">Barangay Cases</a></li>
          <li><a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Underage Patients</a></li>
          <li><a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Sputum Log</a></li>
          <li><a href="<?php echo e(url('closeContact')); ?>" class="nav-link">Close Contact</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Settings">
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span>
          <span class="menu-text">Settings</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Logout">
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            <span class="menu-text">Logout</span>
          </button>
        </form>
      </li>

    </ul>
  </div>

  <div class="header" id="header">
    <div class="header-left">
      <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>

    <!-- <div class="header-right">
      <div class="user-profile">
        <div class="user-avatar">
          <i class="fas fa-user"></i>
        </div>
        <div class="user-info">
          <span>Admin</span>
        </div>
      </div>
    </div> -->

  </div>

  <div class="main-content py-4" id="mainContent">
    <h3>Patient List</h3>

    <div class="d-flex justify-content-between align-items-center mb-2">
      <!-- Live Search Input -->
      <input 
        id="patientSearch" 
        class="form-control w-25" 
        placeholder="Search by name"
      >

      <!-- Add New Patient Button -->
      <a href="<?php echo e(url('form/page1')); ?>" class="btn add-patient-btn btn-success">
        <i class="fas fa-plus me-2"></i>Add New Patient
      </a>
    </div>

      <div class="patient-card shadow-sm border-0">
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Full Name</th>
                  <th>Age</th>
                  <th>Sex</th>
                  <th>Address</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>0001</td>
                  <td>Janrey R. Cambe</td>
                  <td>31</td>
                  <td>Male</td>
                  <td>Tagoloan, Misamis Oriental</td>
                  <td class="text-center">
                    <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fas fa-edit me-1"></i>Edit</a>
                    <a href="<?php echo e(url('patientProfile')); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye me-1"></i>View</a>
                    <a href="<?php echo e(url('error')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt me-1"></i>Delete</a>
                  <!-- <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div> -->
                </td>
                </tr>
                <tr>
                  <td>0002</td>
                  <td>Monita Rose Naguio</td>
                  <td>24</td>
                  <td>Female</td>
                  <td>Cagayan de Oro City</td>
                  <td class="text-center">
                    <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fas fa-edit me-1"></i>Edit</a>
                    <a href="<?php echo e(url('patientProfile')); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye me-1"></i>View</a>
                    <a href="<?php echo e(url('error')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt me-1"></i>Delete</a>
                  <!-- <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div> -->
                </td>
                </tr>
                <tr>
                  <td>0003</td>
                  <td>Bernard B. Madjos</td>
                  <td>23</td>
                  <td>Male</td>
                  <td>Cagayan de Oro City</td>
                  <td class="text-center">
                    <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fas fa-edit me-1"></i>Edit</a>
                    <a href="<?php echo e(url('patientProfile')); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye me-1"></i>View</a>
                    <a href="<?php echo e(url('error')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt me-1"></i>Delete</a>
                  <!-- <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div> -->
                </td>
                </tr>
                <tr>
                  <td>0004</td>
                  <td>Yancy Kent Maputol</td>
                  <td>23</td>
                  <td>Male</td>
                  <td>Cagayan de Oro City</td>
                  <td class="text-center">
                    <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fas fa-edit me-1"></i>Edit</a>
                    <a href="<?php echo e(url('patientProfile')); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye me-1"></i>View</a>
                    <a href="<?php echo e(url('error')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt me-1"></i>Delete</a>
                  <!-- <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div> -->
                </td>
                </tr>
                <tr>
                  <td>0005</td>
                  <td>Syra Mae D. Alampayan</td>
                  <td>21</td>
                  <td>Female</td>
                  <td>Misamis Oriental</td>
                  <td class="text-center">
                    <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fas fa-edit me-1"></i>Edit</a>
                    <a href="<?php echo e(url('patientProfile')); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye me-1"></i>View</a>
                    <a href="<?php echo e(url('error')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt me-1"></i>Delete</a>
                  <!-- <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div> -->
                </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- The Modal -->
        <div class="modal fade" id="myModal">
          <div class="modal-dialog">
            <div class="modal-content">
              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">Patient Information</h4>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                ></button>
              </div>

              <!-- Modal body -->
              <div class="modal-body">
                <form action="" method="post">
                  <label for="name">Full Name</label>
                  <input type="text" name="name" id="name" class="form-control mt-2" placeholder="Full Name">
                  <label for="age">Age</label>
                  <input type="text" name="age" id="age" class="form-control mt-2" placeholder="Age">
                  <label for="address">Address</label>
                  <input type="text" name="address" id="address" class="form-control mt-2" placeholder="Address">
                  <label for="sex">Sex</label>
                  <input type="text" name="sex" id="sex" class="form-control mt-2" placeholder="Sex">
                </form>
              </div>

              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success me-2">Save Changes</button>
              </div>
            </div>
          </div>
        </div>

        <div class="card-footer">Showing 1 to 5 of 5 entries</div>
      </div>
  </div>



  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="<?php echo e(url('assets/js/sidebarToggle.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/rotate-icon.js')); ?>"></script>

  <!-- <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script> -->
  <!-- <script src="<?php echo e(url('assets/js/script.js')); ?>"></script> -->

  <script>
    document.getElementById('patientSearch').addEventListener('keyup', function() {
      let value = this.value.toLowerCase();
      let rows = document.querySelectorAll("table tbody tr");

      rows.forEach(row => {
          let text = row.textContent.toLowerCase();
          row.style.display = text.includes(value) ? '' : 'none';
      });
    });
  </script>

  
</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/patiente.blade.php ENDPATH**/ ?>