<div class="card mb-4 border-0 shadow-sm welcome-card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
      <i class="fas fa-user-shield me-2 text-success fs-4"></i>
      <h5 class="mb-0 fw-semibold text-dark">Welcome back, System Administrator!</h5>
    </div>
    <span class="text-muted small" id="current-date"></span>
  </div>
</div><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/welcome-card.blade.php ENDPATH**/ ?>