<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>TB DOTS - Patient Lists</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>" />
    <link rel="icon" href="<?php echo e(url('assets/img/lungs.png')); ?>">
    <style>
        /* Main Content */
        /* .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 24px;
        } */

        .page-content {
            background: white;
            padding: 20px 30px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 24px;
            position: sticky;
            top: 24px;
            z-index: 100;
        }

        .page-title {
            font-size: 28px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
        }

        /* Navigation Tabs */
        .custom-tabs {
            display: flex;
            border-bottom: 2px solid #e2e8f0;
            gap: 20px;
        }

        .nav-tab {
            background: none;
            border: none;
            padding: 10px 12px;
            font-size: 16px;
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 8px;
            border-bottom: 3px solid transparent;
            font-weight: 500;
            cursor: pointer;
            transition: 0.1s ease;
        }

        .nav-tab i {
            font-size: 20px;
        }

        .nav-tab.active {
            color: #18a678;
            border-bottom-color: #18a678;
            font-weight: 600;
        }

        .nav-tab.active i {
            color: #18a678;
        }

        .nav-tab:hover {
            color: #18a678;
        }


        .info-section {
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e2e8f0;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .info-item {
            display: flex;
            padding: 12px 0;
            /* border-bottom: 1px solid #f1f5f9; */
        }

        .info-label {
            color: #636e72;
            width: 140px;
            flex-shrink: 0;
        }

        .info-value {
            color: #475569;
            font-weight: 500;
            flex: 1;
        }



        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .floating-actions {
                right: 15px;
                padding: 10px 5px;
            }

            .action-btn {
                width: 40px;
                height: 40px;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .nav-tabs {
                overflow-x: auto;
                white-space: nowrap;
            }

            .nav-tab {
                flex-shrink: 0;
            }
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }


        /* Status Badges */
        /* .status-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            background: #dcfce7;
            color: #166534;
        } */
         

    </style>
</head>

<body>

    <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">
        <img src="<?php echo e(url('assets/img/lungs.png')); ?>" alt="TB DOTS Logo" />
      </div>
      <div class="sidebar-brand">
        <h2>TB DOTS</h2>
        <p>RHU, Tagoloan</p>
      </div>
    </div>

    <ul class="sidebar-menu" id="sidebarAccordion">
      <li class="menu-item" data-tooltip="Dashboard">
        <a href="<?php echo e(url('admin/dashboard')); ?>" class="active">
          <span class="material-symbols-rounded">grid_view</span>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Patient">
        <a href="#" class="nav-link d-flex align-items-center patient-toggle">
          <span class="material-symbols-rounded">group</span>
          <span class="menu-text">Patient</span>
          <i class="fas fa-chevron-right toggle-arrow"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a class="nav-link" href="<?php echo e(url('form/page1')); ?>">Add Patient</a></li>
          <li><a class="nav-link" href="<?php echo e(url('patient')); ?>">Patient List</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Notification">
        <a href="<?php echo e(url('error')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          <span class="menu-text">Notification</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Generate Reports">
        <a href="#" class="nav-link d-flex align-items-center reports-toggle">
          <span class="material-symbols-rounded">download</span>
          <span class="menu-text">Generate Reports</span>
          <i class="fas fa-chevron-right toggle-arrow rotate-icon"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a href="<?php echo e(url('newlyDiagnosed')); ?>" class="nav-link">Newly Diagnosed</a></li>
          <li><a href="<?php echo e(url('patientTBClassification')); ?>" class="nav-link">Patient TB Classification</a></li>
          <li><a href="<?php echo e(url('anatomicalSite')); ?>" class="nav-link">Patient Anatomical Site</a></li>
          <li><a href="<?php echo e(url('ongoingTreatments')); ?>" class="nav-link">Ongoing Treatment</a></li>
          <li><a href="<?php echo e(url('barangayCases')); ?>" class="nav-link">Barangay Cases</a></li>
          <li><a href="<?php echo e(url('brgyCaseNotification')); ?>" class="nav-link">Barangay Case Notification</a></li>
          <li><a href="<?php echo e(url('quarterlyCaseNotification')); ?>" class="nav-link">Quarterly Report</a></li>
          <li><a href="<?php echo e(url('curedPatients')); ?>" class="nav-link">Treatment Outcome</a></li>
          <li><a href="<?php echo e(url('underAge')); ?>" class="nav-link">Under Age</a></li>
          <li><a href="<?php echo e(url('sputumMonitoring')); ?>" class="nav-link">Sputum Monitoring</a></li>
          <li><a href="<?php echo e(url('intensiveTreatment')); ?>" class="nav-link">Treatment Phases</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Settings">
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span>
          <span class="menu-text">Settings</span>
        </a>
      </li>
      </ul>

      <div class="logout-section">
          <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            <span class="menu-text">Logout</span>
          </button>
        </form>
        </div>

  </div>

  <div class="header" id="header">
    <div class="header-left">
      <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>
  </div>

    <!-- Main Content -->
    <main class="main-content" id="mainContent">
        <div class="d-flex justify-content-between align-items-center">
        <h1 class="page-title">
            Patient / 
            <span style="color: #059669; font-size: 23px;">
                <?php echo e($patient->pat_full_name); ?>

            </span>
        </h1>
        <a href="<?php echo e(url('patient')); ?>" class="btn btn-secondary backBtn">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
    </div>
        <div class="page-content">
            <!-- <h1 class="page-title">Patient / <span style="color: #059669; font-size: 23px;"><?php echo e($patient->pat_full_name); ?></span></h1> -->
            <div class="nav-tabs custom-tabs">
                <button class="nav-tab active" onclick="switchTab(this, 'personal')">
                    <i class="fa-solid fa-user-circle"></i>
                    <span>Patient Demographic</span>
                </button>
                <button class="nav-tab" onclick="switchTab(this, 'diagnosis')">
                    <i class="fa-solid fa-vials"></i>
                    <span>Diagnosis</span>
                </button>
                <button class="nav-tab" onclick="switchTab(this, 'treatment')">
                    <i class="fa-solid fa-calendar-check"></i>
                    <span>Treatment</span>
                </button>
                <button class="nav-tab" onclick="switchTab(this, 'lab')">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Monitoring</span>
                </button>
            </div>

            
            <!--  Tab -->
            <div id="personal-tab" class="tab-content active" style="margin-top: 30px;">

                <div class="info-section">
                    <h2 class="section-title">Dianosing Facility</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Facility Name</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosingFacility->fac_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">NTP Facility Code</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosingFacility->fac_ntp_code ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Province</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosingFacility->fac_province ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Region</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosingFacility->fac_region ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Patient Demographic</h2>
                    <div class="info-grid gap-5">

                        <div>
                            <div class="info-item">
                                <span class="info-label">Name</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_full_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Date of Birth</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->pat_date_of_birth ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Age</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_age ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Sex</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_sex ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Civil Status</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_civil_status ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Permanent Add</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_permanent_address ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">City/ Municipality</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_permanent_city_mun ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Province</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_permanent_province ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Region</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_permanent_region ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Zip Code</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_permanent_zip_code ?? 'N/A'); ?></span>
                            </div>
                        </div>

                        <div>
                            <div class="info-item">
                                <span class="info-label">Contact Number</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_contact_number ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Other Contact Info</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_other_contact ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">PhilHealth No</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_philhealth_no ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Nationality</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_nationality ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Current Address</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_current_address ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">City/ Municipality</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_current_city_mun ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Province</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_current_province ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Region</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_current_region ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Zip Code</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->pat_current_zip_code ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Diagnosis Tab -->
            <div id="diagnosis-tab" class="tab-content" style="margin-top: 30px; display: none;">

                <div class="info-section">
                    <h2 class="section-title">Screening Information</h2>
                    <div class="info-grid gap-5">

                        <div>
                            <div class="info-item">
                                <span class="info-label">Referred by</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->scr_referred_by ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Location</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->scr_location ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Type of Referrer</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->scr_referrer_type ?? 'N/A'); ?></span>
                            </div>
                        </div>

                        <div>
                            <div class="info-item">
                                <span class="info-label">Mode of Screening</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->scr_screening_mode ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Date of Screening</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->screenings->first()->scr_screening_date ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Laboratory Tests</h2>
                    <div class="info-grid gap-5">

                        <div>
                            <div class="info-item">
                                <span class="info-label">Xpert MTB/RIF</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_xpert_test_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Result</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_xpert_result ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Smear Microscopy</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_smear_test_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Result</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_smear_result ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Chest X-ray</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_cxray_test_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Result</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_cxray_result ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Tuberculin Skin Test</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_tst_test_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Result</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_tst_result ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Other Test</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_other_test_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Result</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->screenings->first()->labTests->first()->lab_other_result ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Diagnosis</h2>
                        <div class="info-grid gap-5">

                        <div>
                            <div class="info-item">
                                <span class="info-label">Diagnosis Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->diagnosis->diag_diagnosis_date ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Notification Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->diagnosis->diag_notification_date ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">TB Case Number</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_tb_case_no ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Attending Physician</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_attending_physician ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Referred to</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_referred_to ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Address</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_address ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Facility Code</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_facility_code ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Province</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_province ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Region</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->diag_region ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">TB Disease Classification</h2>
                        <div class="info-grid gap-5">

                        <div>
                            <div class="info-item">
                                <span class="info-label">Bacteriological Status</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->tbClassification->clas_bacteriological_status ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Drug Resistance status</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->tbClassification->clas_drug_resistance_status ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Other Drug Resistance status</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->tbClassification->clas_other_drug_resistant ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Anatomical Site</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->tbClassification->clas_anatomical_site ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Site Other</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->tbClassification->clas_site_other ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Registration Group</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->diagnosis->tbClassification->clas_registration_group ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

            </div>
                

            <!-- Treatment Plan Tab -->
            <div id="treatment-tab" class="tab-content" style="margin-top: 30px; display: none;">

                <div class="info-section">
                    <h2 class="section-title">Treatment Facility</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Facility Name</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentFacilities->first()->trea_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">NTP Facility Code</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentFacilities->first()->trea_ntp_code ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Province</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentFacilities->first()->trea_province ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Region</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentFacilities->first()->trea_region ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">History of TB Treatment</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date Tx Started</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentHistories->first()->hist_date_tx_started ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Name of Treatment Unit</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentHistories->first()->hist_treatment_unit ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Treatment Regimen</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentHistories->first()->hist_regimen ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Outcome</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentHistories->first()->hist_outcome ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Co-morbidities</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date Diagnosed</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->comorbidities->first()->com_date_diagnosed ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Type</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->comorbidities->first()->com_type ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Other</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->comorbidities->first()->com_other ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Treatment</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->comorbidities->first()->com_treatment ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Baseline Information</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Height</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_weight ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Weight</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_height ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Other Vital Signs</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_vital_signs ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Person to Notify in case of Emergency</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_emergency_contact_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Relationship</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_relationship ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Contact Information</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_contact_info ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Diabetes Screening</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_diabetes_screening ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">FBS Screening</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_fbs_screening ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Date Tested</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_date_tested ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">4Ps Beneficiary?</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_four_ps_beneficiary ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Occupation</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->baselineInfos->first()->base_occupation ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">HIV Information</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->hivInfos->first()->hiv_information ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">HIV Test Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->hivInfos->first()->hiv_test_date ?? 'N/A'); ?></span>
                            </div><div class="info-item">
                                <span class="info-label">Confirmatory Test Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->hivInfos->first()->hiv_confirmatory_test_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Result</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->hivInfos->first()->hiv_result ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Started on ARt?</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->hivInfos->first()->hiv_art_started ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Started on CPT?</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->hivInfos->first()->hiv_cpt_started ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Treatment Regimen</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Regimen Type at Start of Treatment</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentRegimens->first()->reg_start_type ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Treatment Start Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->treatmentRegimens->first()->reg_start_date ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Regimen Type at End of Treatment</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentRegimens->first()->reg_end_type ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Outcome</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentOutcomes->first()->out_outcome ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Date of Outcome</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentOutcomes->first()->out_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Reason</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->treatmentOutcomes->first()->out_reason ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Medicine</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date Start</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->prescribedDrugs->first()->drug_start_date ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Drug</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Strength</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_strength ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Unit</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_unit ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Continuation</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_con_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Drug</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_con_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Strength</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_con_strength ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Unit</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->prescribedDrugs->first()->drug_con_unit ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Administration of Drugs</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Location of Treatment</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_location ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Name</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Designation</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_designation ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Type of Tx Supporter</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_type ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Tx Supporter Contact Information</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_contact_info ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Schedule of Treatment</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_treatment_schedule ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Name of DAT/s Used</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->txSupporters->first()->sup_dat_used ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>
                            <div class="info-item">
                                <span class="info-label">Intensive Phase Start Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e(\Carbon\Carbon::parse($patient->adherences->first()->pha_intensive_start ?? 'N/A')->format('F j, Y')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Intensive Phase End Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adherences->first()->pha_intensive_end ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Continuation Phase Start Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adherences->first()->pha_continuation_start ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Continuation Phase End Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adherences->first()->pha_continuation_end ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Weight</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adherences->first()->pha_weight ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Height(cm) for Children</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adherences->first()->pha_child_height ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>



            </div>


            <!-- Lab Results Tab -->
            <div id="lab-tab" class="tab-content" style="margin-top: 30px; display: none;">

                <div class="info-section">
                    <h2 class="section-title">Serious Adverse Events and AEs of Special Interest</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date of AE</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adverseEvents->first()->adv_ae_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Specific AE</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adverseEvents->first()->adv_specific_ae ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Date Reported to FDA</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->adverseEvents->first()->adv_fda_reported_date ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Patient Progress Report Form</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->progress->first()->prog_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Problem</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->progress->first()->prog_problem ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Action Taken</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->progress->first()->prog_action_taken ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Plan</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->progress->first()->prog_plan ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Close Contact</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Name</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_name ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Age</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_age ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Sex</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_sex ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Relationship</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_relationship ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Initial Screening</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_initial_screening ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Ff-up</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_follow_up ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Remarks</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->close_contacts->first()->con_remarks ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Sputum Monitoring</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date Collected</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->sputum_monitorings->first()->sput_date_collected ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Smear Microscopy/ TB LAMP</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->sputum_monitorings->first()->sput_smear_result ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Xpert MTB/RIF</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->sputum_monitorings->first()->sput_xpert_result ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Chest X-ray</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Date Examined</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->chestXrays->first()->xray_date_examined ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Impression/ Comparative Reading</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->chestXrays->first()->xray_impression ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Descriptive Comments</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->chestXrays->first()->xray_descriptive_comment ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <h2 class="section-title">Post Treatment Follow-up</h2>
                    <div class="info-grid">
                        <div>
                            <div class="info-item">
                                <span class="info-label">Mo.Afer Tx</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->postTreatment->first()->fol_months_after_tx ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Date</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->postTreatment->first()->fol_date ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">CXR Findings</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->postTreatment->first()->fol_cxr_findings ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Smear/ Xpert</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->postTreatment->first()->fol_smear_xpert ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">TBC & DST</span>
                                <span class="info-value d-flex justify-content-end"><?php echo e($patient->postTreatment->first()->fol_tbc_dst ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div>

                        </div>
                    </div>
                </div>

            </div>



        </div>
    </main>

    <script src="<?php echo e(url('assets/js/patientProfile.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>
    
    <script src="<?php echo e(url('assets/js/sidebarToggle.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/rotate-icon.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/admin/patientProfile.blade.php ENDPATH**/ ?>