<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Sex</th>
            <th>Age</th>
            <th>Address</th>
            <th>Contact</th>
            <th>Diagnosis Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($patient->id); ?></td>
                <td><?php echo e($patient->full_name); ?></td>
                <td><?php echo e($patient->sex); ?></td>
                <td><?php echo e($patient->age); ?></td>
                <td><?php echo e($patient->current_address); ?></td>
                <td><?php echo e($patient->contact_number); ?></td>
                <td><?php echo e($patient->diagnosis_date); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">No results found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

 <script>
function searchPatient(search_value){
    $.ajax({
        url: "<?php echo e(route('patients.search')); ?>",
        type: "GET",
        data: { search: search_value },
        success: function(response){
            $('#results').html(response);
        }
    });
}
</script><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/patients/table.blade.php ENDPATH**/ ?>