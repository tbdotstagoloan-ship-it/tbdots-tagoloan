<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Patient Summary Report</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<style>
  .icons {
    background: #f1c40f;
    color: #fff;
    padding: 6px 12px;
    border-radius: 4px;
    text-decoration: none;
    color: white;
    display: inline-flex; /* needed for align-items + justify-content */
    align-items: center;
    justify-content: center;
    transition: background 0.3s ease; /* smooth hover */
}

.icons:hover {
    background: #f39c12;
    color: #fff !important;
}

.icon {
    background: #e74c3c;
    padding: 6px 12px;
    border-radius: 4px;
    text-decoration: none;
    color: white;
    display: inline-flex; /* needed for align-items + justify-content */
    align-items: center;
    justify-content: center;
    transition: background 0.3s ease; /* smooth hover */
}

.icon:hover {
    background: #c0392b;
}
  .backBtn {
    border-radius: 4px;
    border: 1px solid #ccc;
    background-color: #ffffff;   /* always white */
    color: #636e72 !important;   /* default text color */
    font-weight: 600;
}

.backBtn:hover {
    background-color: #ffffff !important; /* stays white */
    border: 1px solid #ccc;            /* stays same border */
    color: #2d3436 !important;            /* text turns black */
}

.backBtn i {
    color: #636e72 !important;   /* icon stays dark slate */
}

.backBtn:hover i {
    color: #2d3436 !important;   /* icon does NOT change */
}
</style>
</head>
<body class="container py-4">

  <h2 class="mb-4">TB DOTS Patient Summary Report</h2>

  <div class="card p-3">
    <h4>I. Patient Demographic</h4>
    <p><strong>Patient ID:</strong> <?php echo e($patient->id); ?> </p>
    <p><strong>Full Name:</strong> <?php echo e($patient->pat_full_name); ?> </p>
    <p><strong>Sex:</strong> <?php echo e($patient->pat_sex); ?></p>
    <p><strong>Age:</strong> <?php echo e($patient->pat_age); ?></p>
    <p><strong>Date of Birth:</strong> <?php echo e($patient->pat_date_of_birth); ?> </p>
    <p><strong>Civil Status:</strong> <?php echo e($patient->pat_civil_status); ?> </p>
    <p><strong>Address:</strong> 
    <?php echo e($patient->pat_permanent_address); ?>,
    <?php echo e($patient->pat_permanent_city_mun); ?>,
    <?php echo e($patient->pat_permanent_region); ?>,
    <?php echo e($patient->pat_permanent_zip_code); ?>

    </p>
    <p><strong>Contact:</strong> <?php echo e($patient->pat_contact_number); ?></p>
    <p><strong>Nationality:</strong> <?php echo e($patient->pat_nationality); ?> </p>
    <!-- <p><strong>Medical Notes:</strong> <?php echo e($patient->medical_notes ?? 'No notes available'); ?></p> -->
    <hr>
    <h4>II. Facility & Case Information</h4>
    <p><strong>Diagnosing Facility:</strong> <?php echo e($patient->pat_diagnosing_facility); ?> </p>
    <p><strong>NTP Facility Code:</strong> <?php echo e($patient->pat_ntp_facility_code); ?> </p>
    <p><strong>Province:</strong> <?php echo e($patient->pat_province); ?> </p>
    <p><strong>Region:</strong> <?php echo e($patient->pat_region); ?> </p>
    <p><strong>Date Registered:</strong> <?php echo e($diagnosis->diag_diagnosis_date); ?> </p>
    <p><strong>TB Case Number:</strong> <?php echo e($diagnosis->diag_tb_case_number); ?> </p>
    <hr>
    <h4>III. Diagnostic Information</h4>
    <p><strong>Type of TB:</strong> <?php echo e($diagnosis->diag_bacteriological_status); ?> </p>
    <p><strong>Xpert MTB/RIF:</strong> <?php echo e($diagnosis->diag_xpert_result); ?> </p>
    <p><strong>Date:</strong> <?php echo e($diagnosis->diag_xpert_test_date); ?> </p>
    <p><strong>Smear Microscopy/TB LAMP</strong> <?php echo e($diagnosis->diag_smear_result); ?> </p>
    <p><strong>Date:</strong> <?php echo e($diagnosis->diag_smear_result); ?> </p>
    <p><strong>Chest X-ray:</strong> <?php echo e($diagnosis->diag_chest_xray_result); ?> </p>
    <p><strong>Date:</strong> <?php echo e($diagnosis->diag_chest_xray_result); ?> </p>
    <hr>
    <h4>IV. Treatment Information</h4>
    <p><strong>Treatment Category:</strong> <?php echo e($diagnosis->diag_registration_group); ?> </p>
    <p><strong>Treatment Start Date:</strong> <?php echo e($treatment->trt_treatment_start_date); ?> </p>
    <p><strong>Treatment Regimen:</strong> <?php echo e($treatment->trt_regimen_type_start_treatment); ?> </p>
    <p><strong>Attending Physician:</strong> <?php echo e($diagnosis->diag_attending_physician); ?> </p>
    <hr>
    <h4>V. Follow up & Monitoring</h4>
    <p><strong>Intensive Phase:</strong> <?php echo e($treatment->trt_intensive_phase_start); ?> </p>
    <p><strong>Continuation Phase:</strong> <?php echo e($treatment->trt_continuation_phase_start); ?> </p>
    <hr>
    <h4>VI. Treatment Outcome</h4>
    <p><strong>Outcome:</strong></p>
    <p><strong>Date Declared:</strong></p>
    <p><strong>Remarks:</strong></p>
  </div>

  <div class="mt-3">
    <a href="<?php echo e(url()->previous()); ?>" class="btn backBtn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
    <button onclick="window.print()" class="btn icons btn-warning"><i class="fas fa-print me-1"></i>Print</button>
    <a href="<?php echo e(route('patient.summary.pdf', $patient->id)); ?>" class="btn icon btn-danger"><i class="fas fa-file-pdf me-1"></i>PDF</a>
  </div>

  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/patient/summary.blade.php ENDPATH**/ ?>