<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Patient Summary Report</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #333; }
        h2, h4 { text-align: center; margin: 0; }
        .meta { margin-bottom: 20px; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #444; padding: 6px; text-align: left; }
        th { background: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Patient Summary Report</h2>
    <div class="meta">
        <h4><?php echo e($clinic); ?></h4>
        <p>Generated: <?php echo e($generated); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Birth Date</th>
                <th>Sex</th>
                <th>Address</th>
                <th>TB Case #</th>
                <th>Diagnosis Date</th>
                <th>Physician</th>
                <th>Drug</th>
                <th>Strength</th>
                <th>Unit</th>
                <th>Outcome</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->name); ?></td>
                <td><?php echo e($p->birth_date); ?></td>
                <td><?php echo e($p->sex); ?></td>
                <td><?php echo e($p->address); ?></td>
                <td><?php echo e($p->tb_case_no); ?></td>
                <td><?php echo e($p->diagnosis_date); ?></td>
                <td><?php echo e($p->physician); ?></td>
                <td><?php echo e($p->drug); ?></td>
                <td><?php echo e($p->strength); ?></td>
                <td><?php echo e($p->unit); ?></td>
                <td><?php echo e($p->outcome); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/reports/patient_summary.blade.php ENDPATH**/ ?>