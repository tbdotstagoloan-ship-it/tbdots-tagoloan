<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>TB DOTS - Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
    <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
    <style>
      .search-container {
        position: relative;
        margin-bottom: 20px;
      }
      .search-input {
        width: 25%;
        padding: 12px 40px 12px 20px;
        border: 1px solid #e0e6ed;
        border-radius: 8px;
        font-size: 14px;
        background-color: #f8f9ff;
        transition: all 0.3s ease;
      }
      .search-input:focus {
        outline: none;
        border-color: #fdfeff;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        background-color: white;
      }
      .search-icon {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        color: #2c3e50;
        font-size: 16px;
        margin-left: 5px;
      }
      .card {
        border: 1px solid #e0e6ed;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        background: white;
      }
      .card-header {
        background: white;
        border-bottom: 1px solid #e0e6ed;
        padding: 20px;
        border-radius: 12px 12px 0 0;
      }
      .generate-reports-title {
        color: #6c757d;
        font-size: 16px;
        font-weight: 600;
        margin: 0;
      }
      .table-container {
        min-height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
       .no-data-message {
        color: #6c757d;
        font-size: 14px;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('admin/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form/page1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patient')); ?>" class="nav-link">Patient List</a>
          </li>
          <li>
            <a href="<?php echo e(url('patientProfile')); ?>" class="nav-link">Patient Profile</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('medicalInformation')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Medical Information
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('adherenceTrackingData')); ?>">
           <span class="material-symbols-rounded">monitoring</span>
          Adherence Track Data
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Patient Health</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Adherence Report</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Treatment Logs</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

    <div class="main-content">
      <h3 style="margin-bottom: 30px; color: #2c3e50; font-weight: 600">
        Reports
      </h3>
      
      <div class="card">
        <div class="card-header">
          <div class="search-container">
            <input type="text" class="search-input" placeholder="Search here" id="searchInput">
            <i class="fas fa-search search-icon"></i>
          </div>
        </div>

        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="generate-reports-title">Generate Report</h5>
            <button onclick="window.location.href='<?php echo e(url('error')); ?>'" class="btn btn-danger">
              <i class="fas fa-chart-line me-2"></i>Generate Report
            </button>
          </div>
        

        <div class="table-container">
          <div class="no-data-message">
            No data available in table
          </div>
        </div>
        </div>
      </div>

      
          </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/admin/reports.blade.php ENDPATH**/ ?>