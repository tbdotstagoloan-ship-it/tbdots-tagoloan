<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>TB DOTS - Notification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
    <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
  </head>

  <body>
    <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('admin/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('diagnosis')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Diagnosis
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('notification')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          Notification
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form/page1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patiente')); ?>" class="nav-link">Patient List</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('treatment')); ?>">
           <span class="material-symbols-rounded">medical_services</span>
          Treatment
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('treatmentOutcome')); ?>">
           <span class="material-symbols-rounded">health_metrics</span>
          Treatment Outcome
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('feedback')); ?>" class="nav-link">Patient Feedback</a>
          </li>
          <li>
            <a href="<?php echo e(url('diagClassification')); ?>" class="nav-link">Patient Diagnosis</a>
          </li>
          <li>
            <a href="<?php echo e(url('notificationLog')); ?>" class="nav-link">Notification Log</a>
          </li>
          <li>
            <a href="<?php echo e(url('ongoingTreatment')); ?>" class="nav-link">Ongoing Treatment</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Cured Patients</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Lost to Follow-up</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Failed Treatments</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Expired Patients</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Intensive Treatment</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Maintenance Treatment</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Barangay Cases</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Underage Patients</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Sputum Log</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Close Contact</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

    <div class="main-content">
      <h3 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600;">
        List of Patient with ongoing Treatment
      </h3>

      <div class="d-flex justify-content-end mb-2">
        <a href="<?php echo e(url('#')); ?>" class="btn add-product-btn btn-success">
          <i class="fas fa-plus me-2"></i>Add New</a>
      </div>
      
      <div class="card inventory-card shadow-sm border-0">
        <div class="card-body p-0">
          <div class="table-responsive">
                
                <!-- <form action="" method="post" class="p-2">

                  <h5 class="mb-4">Chest X-ray Result</h5>
                  <div class="row">
                    <div class="col-md-4">
                      <label for="">Sputum Test Result</label>
                      <input type="text" name="" class="form-control" placeholder="Sputum Test Result" required>
                    </div>
                    <div class="col-md-4">
                      <label for="">Date Collected</label>
                      <input type="date" name="" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="address">Chest X-ray Result</label>
                      <input type="text" name="address" class="form-control" placeholder="Chest X-ray Result" required>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-6">
                      <label for="sex">Diagnosis Classification</label>
                      <input type="text" name="" class="form-control" placeholder="Diagnosis Classification">
                    </div>
                    <div class="col-md-6">
                      <label for="month">Date Recorded</label>
                      <input type="date" name="month" class="form-control" required>
                    </div>
                  </div>
                  
                  <div class="float-end">
                   <button type="submit" class="btn add-product-btn btn-success">Submit</button>
                </div>
                </form> -->


                <table class="table">
              <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Treatment Duration</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>

                
                
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <!-- <tr>
                  <td>Bernard B. Madjos</td>
                  <td>January 8, 2025</td>
                  <td>July 11 09:00:00 AM</td>
                  <td>False</td>
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>Yancy Kent Maputol</td>
                  <td>July 5, 2025</td>
                  <td>July 12 08:30:00 AM</td>
                  <td>True</td>
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>Syra Mae Alampayan</td>
                  <td>July 6, 2025</td>
                  <td>July 13, 2025 07:45:00 AM</td>
                  <td>True</td>
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>Monita Rose Naguio</td>
                  <td>July 7, 2025</td>
                  <td>July 14, 2025 08:15:00 AM</td>
                  <td>False</td>
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr> -->

              </tbody>
            </table>
  
                </div>
              </div>
            </div>
          </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/reports/ongoingTreatment.blade.php ENDPATH**/ ?>