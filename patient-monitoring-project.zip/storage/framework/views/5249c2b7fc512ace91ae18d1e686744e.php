<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>TB DOTS - Patient List</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="icon" href="<?php echo e(url('assets/img/lungs.png')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
</head>

<body>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">
        <img src="<?php echo e(url('assets/img/lungs.png')); ?>" alt="TB DOTS Logo" />
      </div>
      <div class="sidebar-brand">
        <h2>TB DOTS</h2>
        <p>RHU, Tagoloan</p>
      </div>
    </div>

    <ul class="sidebar-menu" id="sidebarAccordion">
      <li class="menu-item" data-tooltip="Dashboard">
        <a href="<?php echo e(url('admin/dashboard')); ?>" class="active">
          <span class="material-symbols-rounded">grid_view</span>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Patient">
        <a href="#" class="nav-link d-flex align-items-center patient-toggle">
          <span class="material-symbols-rounded">group</span>
          <span class="menu-text">Patient</span>
          <i class="fas fa-chevron-left toggle-arrow"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a class="nav-link" href="<?php echo e(url('form/page1')); ?>">Add Patient</a></li>
          <li><a class="nav-link" href="<?php echo e(url('patient')); ?>">Patient List</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Notification">
        <a href="<?php echo e(url('error')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          <span class="menu-text">Notification</span>
        </a>
      </li>

      <li class="nav-item menu-item" data-tooltip="Generate Reports">
        <a href="#" class="nav-link d-flex align-items-center reports-toggle">
          <span class="material-symbols-rounded">download</span>
          <span class="menu-text">Generate Reports</span>
          <i class="fas fa-chevron-right toggle-arrow rotate-icon"></i>
        </a>
        <ul class="submenu list-unstyled ps-4">
          <li><a href="<?php echo e(url('newly-diagnosed')); ?>" class="nav-link">Newly Diagnosed</a></li>
          <li><a href="<?php echo e(url('relapse')); ?>" class="nav-link">Relapse Patients</a></li>
          <li><a href="<?php echo e(url('bacteriologically-confirmed')); ?>" class="nav-link">TB Classification</a></li>
          <li><a href="<?php echo e(url('pulmonary')); ?>" class="nav-link">Anatomical Site</a></li>
          <li><a href="<?php echo e(url('ongoing-treatment')); ?>" class="nav-link">Ongoing Treatment</a></li>
          <li><a href="<?php echo e(url('barangay-cases')); ?>" class="nav-link">Barangay Cases</a></li>
          <li><a href="<?php echo e(url('intensive-treatment')); ?>" class="nav-link">Treatment Phases</a></li>
          <li><a href="<?php echo e(url('underage')); ?>" class="nav-link">Under Age</a></li>
          <li><a href="<?php echo e(url('sputum-monitoring')); ?>" class="nav-link">Sputum Monitoring</a></li>
          <li><a href="<?php echo e(url('cured')); ?>" class="nav-link">Treatment Outcome</a></li>
          <li><a href="<?php echo e(url('barangay-cases-notification')); ?>" class="nav-link">Barangay Case Notification</a></li>
          <li><a href="<?php echo e(url('quarterly-cases-notification')); ?>" class="nav-link">Quarterly Report</a></li>
        </ul>
      </li>

      <li class="menu-item" data-tooltip="Settings">
        <a href="<?php echo e(url('patient-accounts')); ?>">
          <span class="material-symbols-rounded">Manage_accounts</span>
          <span class="menu-text">Patient Accounts</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Settings">
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span>
          <span class="menu-text">Settings</span>
        </a>
      </li>

      <li class="menu-item" data-tooltip="Logout">
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            <span class="menu-text">Logout</span>
          </button>
        </form>
      </li>

    </ul>
  </div>

  <div class="header" id="header">
    <div class="header-left">
      <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>
  </div>

  <div class="main-content py-4" id="mainContent">
      <h3>Patient Summary Report</h3>

       
          </div>



  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="<?php echo e(url('assets/js/sidebarToggle.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/rotate-icon.js')); ?>"></script>

  <!-- <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script> -->
  <!-- <script src="<?php echo e(url('assets/js/script.js')); ?>"></script> -->

</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/admin/patientSummary.blade.php ENDPATH**/ ?>