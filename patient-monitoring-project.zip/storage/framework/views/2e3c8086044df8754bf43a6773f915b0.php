<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TB DOTS | Log-In</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <link rel="icon" href="<?php echo e(url('assets/img/lungs.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/login.css')); ?>">
    
</head>
<body>
    
    <div class="page-wrapper">
        <!-- TOP LOGO -->
        <div class="top-logo">
            <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" alt="logo">
        </div>

    <div class="login-container">
        <div class="login-header">
            <h2>Welcome to TB DOTS [PMS]</h2>
        </div>

        <!-- Laravel Status Message -->
        <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4 text-red-500 text-sm text-center','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 text-red-500 text-sm text-center','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

        <!-- Login Form -->
        <form id="form" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="text" id="email" name="email" placeholder="Email" type="text" value="<?php echo e(old('email')); ?>">
                <div class="error"></div>
                <!-- <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" id="password" name="password" placeholder="Password" type="text">
                <span class="toggle-password" onclick="togglePassword('password', this)">
                  <i class="fa-solid fa-eye-slash"></i>
              </span>
                <div class="error"></div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="login-btn" id="login-btn">
                <span id="login-btn-text">
                    <i class="fas fa-sign-in-alt"></i> Sign In
                </span>
            </button>
        </form>
        <div class="text-center mt-4" style="font-size: 0.90rem;">
            <p>Don't have an account? <a href="<?php echo e(route('register')); ?>" style="color: #2575fc; font-weight: 600; font-size: 0.90rem; text-decoration: none;">
                Sign Up
            </a>
            </p>
        </div>


    </div>
</div>

</body>
<!-- <script src="<?php echo e(url('assets/js/togglePassword.js')); ?>"></script> -->

<script>
  const form = document.getElementById('form');
  const email = document.getElementById('email');
  const password = document.getElementById('password');

  // Allowed characters: letters, numbers, dot, @
  const hasInvalidChars = value => {
    const re = /[^a-zA-Z0-9.@]/;
    return re.test(value);
  };

  const setError = (element, message) => {
    const inputControl = element.parentElement;
    let errorDisplay = inputControl.querySelector('.error');

    if (!errorDisplay) {
      errorDisplay = document.createElement('div');
      errorDisplay.className = 'error';
      inputControl.appendChild(errorDisplay);
    }

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success');
  };

  const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    if (errorDisplay) {
      errorDisplay.innerText = '';
    }

    inputControl.classList.add('success');
    inputControl.classList.remove('error');
  };

  const isValidEmail = email => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  };

  // 🔹 Real-time validation per field
  const liveValidateEmail = () => {
    const emailValue = email.value.trim();

    if (emailValue === '') {
      setError(email, 'Email is required');
    } else if (hasInvalidChars(emailValue)) {
      setError(email, "Special characters are not allowed");
    } else {
      setSuccess(email); // valid so far
    }
  };

  const liveValidatePassword = () => {
    const passwordValue = password.value.trim();

    if (passwordValue === '') {
      setError(password, 'Password is required');
    } else if (passwordValue.length < 8) {
      // Don’t show error until submit → just green if okay so far
      setSuccess(password);
    } else {
      setSuccess(password);
    }
  };

  // 🔹 Final validation on submit (full rules)
  const validateOnSubmit = () => {
    let isValid = true;
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();

    // Email strict check
    if (emailValue === '') {
      setError(email, 'Email is required');
      isValid = false;
    } else if (hasInvalidChars(emailValue)) {
      setError(email, "Special characters are not allowed");
      isValid = false;
    } else if (!isValidEmail(emailValue)) {
      setError(email, 'Provide a valid email address');
      isValid = false;
    } else {
      setSuccess(email);
    }

    // Password strict check
    if (passwordValue === '') {
      setError(password, 'Password is required');
      isValid = false;
    } else if (passwordValue.length < 8) {
      setError(password, 'Password must be at least 8 characters');
      isValid = false;
    } else {
      setSuccess(password);
    }

    return isValid;
  };

  // ✅ Real-time validation (per field only)
  email.addEventListener('input', liveValidateEmail);
  password.addEventListener('input', liveValidatePassword);

  // ✅ Final validation on submit
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (validateOnSubmit()) {
      form.submit();
    }
  });
</script>

<script>
function togglePassword(fieldId, el) {
    const input = document.getElementById(fieldId);
    const icon = el.querySelector("i");

    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    } else {
        input.type = "password";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    }
}
</script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if($errors->has('email')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            text: '<?php echo e($errors->first('email')); ?>',
            confirmButtonColor: '#d33',
            confirmButtonText: 'Try Again'
        });
    </script>
<?php endif; ?>



</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/auth/login.blade.php ENDPATH**/ ?>