<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>TB DOTS - Add New Patient</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
  <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
</head>

<body>
  <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('home/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patient')); ?>" class="nav-link">Patient List</a>
          </li>
          <li>
            <a href="<?php echo e(url('patientProfile')); ?>" class="nav-link">Patient Profile</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('medicalInformation')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Medical Information
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('adherenceTrackingData')); ?>">
           <span class="material-symbols-rounded">monitoring</span>
          Adherence Track Data
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Patient Health</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Adherence Report</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Treatment Logs</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

  <div class="main-content">
    <h4 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600">
      National TB Control Program
    </h4>


    <div class="card inventory-card shadow-sm border-0">
      <div class="card-body p-0">
        <div class="table-responsive">

          <form action="" method="post" class="p-2">

          <!-- <h5 class="mb-4">F. Patient Progress Report Form</h5>
            <div class="row mb-2">
                    <div class="col-md-3">
                        <label for="date">Date</label>
                        <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="problem">Problem</label>
                        <input type="text" name="problem" class="form-control" placeholder="Reason of Absence" required>
                    </div>
                    <div class="col-md-3">
                        <label for="action_taken">Action Taken</label>
                        <input type="text" name="action_taken" class="form-control" placeholder="Action Taken" required>
                    </div>
                    <div class="col-md-3">
                        <label for="plan">Plan</label>
                        <input type="text" name="plan" class="form-control" placeholder="Plan" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">G. Close Contacts</h5>
                  <div class="row">
                    <div class="col-md-3">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Name" required>
                    </div>
                    <div class="col-md-3">
                        <label for="age">Age</label>
                        <input type="text" name="age" class="form-control" placeholder="Age" required>
                    </div>
                    <div class="col-md-3">
                        <label for="sex">Sex</label>
                        <select name="sex" class="form-control form-select" required>
                            <option value="" disabled selected>Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="relationship">Relationship</label>
                        <input type="text" name="relationship" class="form-control" placeholder="Relationship" required>
                    </div>
                  </div>

                  <div class="row mb-2">
                    <div class="col-md-4">
                        <label for="initial_screening">Initial Screening</label>
                        <input type="date" name="initial_screening" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="Ff_up">Ff-up</label>
                        <input type="date" name="Ff-up" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="remarks">Remarks</label>
                        <input type="text" name="remarks" class="form-control" placeholder="TB/ TPT Case Number" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">H. Sputum Monitoring</h5>
                  <div class="row mb-2">
                    <div class="col-md-4">
                        <label for="date_collected">Date Collected</label>
                        <input type="date" name="date_collected" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="smear_microscopy">Smear Microscopy/ TB LAMP</label>
                        <input type="text" name="smear_microscopy" class="form-control" placeholder="Smear Microscopy/ TB LAMP" required>
                    </div>
                    <div class="col-md-4">
                        <label for="xpert_mtb">Xpert MTB/RIF</label>
                        <input type="text" name="xpert_mtb" class="form-control" placeholder="Xpert MTB/RIF" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">I. Chest X-ray</h5>
                  <div class="row">
                    <div class="col-md-2">
                      <label for="month">Month</label>
                      <input type="text" name="month" class="form-control" placeholder="B" required>
                    </div>
                    <div class="col-md-3">
                      <label for="date_examined">Date Examined</label>
                      <input type="date" name="date_examined" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for="impression">Impression/ Comparative Reading</label>
                      <select name="impression" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="Normal">Normal</option>
                        <option value="Abnormal suggestive of TB">Abnormal suggestive of TB</option>
                        <option value="Abnormal not suggestive of TB">Abnormal not suggestive of TB</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for="descriptive_comments">Descriptive Comments</label>
                      <input type="text" name="descriptive_comments" class="form-control" placeholder="Descriptive Comments" required>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-2">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="" required>
                    </div>
                    <div class="col-md-3">
                      <label for="date"></label>
                      <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for=""></label>
                      <select name="" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="">Improved</option>
                        <option value="">Stable/Unchanged</option>
                        <option value="">Worsened</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="Descriptive Comments" required>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-2">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="" required>
                    </div>
                    <div class="col-md-3">
                      <label for="date"></label>
                      <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                      <label for=""></label>
                      <select name="" class="form-control form-select" required>
                        <option value="" disabled selected>Select</option>
                        <option value="">Improved</option>
                        <option value="">Stable/Unchanged</option>
                        <option value="">Worsened</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="Descriptive Comments" required>
                    </div>
                  </div>

                  <hr>
                  <h5 class="mb-4">J. Post Treatment Follow-up</h5>
                  <div class="row">
                    <div class="col-md-2">
                      <label for="mo_aftertx">Mo. After Tx</label>
                      <input type="text" name="mo_aftertx" class="form-control" placeholder="PT" required>
                    </div>
                    <div class="col-md-2">
                      <label for="date">Date</label>
                      <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                      <label for="cxr_findings">CXR Findings</label>
                      <input type="text" name="cxr_findings" class="form-control" placeholder="CXR Findings" required>
                    </div>
                    <div class="col-md-3">
                      <label for="smear">Smear/ Xpert</label>
                      <input type="text" name="smear" class="form-control" placeholder="Smear/ Xpert" required>
                    </div>
                    <div class="col-md-3">
                      <label for="tbc">TBC & DST</label>
                      <input type="text" name="tbc" class="form-control" placeholder="TBC & DST" required>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-2">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="PT" required>
                    </div>
                    <div class="col-md-2">
                      <label for="date"></label>
                      <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="CXR Findings" required>
                    </div>
                    <div class="col-md-3">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="Smear/ Xpert" required>
                    </div>
                    <div class="col-md-3">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="TBC & DST" required>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-2">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="PT" required>
                    </div>
                    <div class="col-md-2">
                      <label for="date"></label>
                      <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="CXR Findings" required>
                    </div>
                    <div class="col-md-3">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="Smear/ Xpert" required>
                    </div>
                    <div class="col-md-3">
                      <label for=""></label>
                      <input type="text" name="" class="form-control" placeholder="TBC & DST" required>
                    </div>
                  </div> -->
                  
              <div class="float-end">
                <button type="submit" class="btn add-product-btn btn-success"><i class="fas fa-save me-2"></i>Add New Patient</button>
              </div>

          </form>

        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/form5.blade.php ENDPATH**/ ?>