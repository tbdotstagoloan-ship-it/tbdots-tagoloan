<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TB DOTS - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
  <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>">
</head>

<body>
  <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('home/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patient')); ?>" class="nav-link">Patient List</a>
          </li>
          <li>
            <a href="<?php echo e(url('patientProfile')); ?>" class="nav-link">Patient Profile</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('medicalInformation')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Medical Information
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('adherenceTrackingData')); ?>">
           <span class="material-symbols-rounded">monitoring</span>
          Adherence Track Data
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Patient Health</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Adherence Report</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Treatment Logs</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

  <div class="main-content">

    <div class="card mb-4 border-0 shadow-sm welcome-card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
          <i class="fas fa-user-shield me-2 text-success fs-4"></i>
          <h5 class="mb-0 fw-semibold text-dark">Welcome back, System Administrator!</h5>
        </div>
        <span class="text-muted small" id="current-date"></span>
      </div>
    </div>


    <div class="row g-4">
    <div class="col-md-3">
      <div class="dashboard-card doctors">
        <h5>Total Doctors</h5>
        <p class="fs-4">1</p>
        <div class="bg-icon"><i class="fas fa-user-md"></i></div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="dashboard-card nurses">
        <h5>Total Nurses</h5>
        <p class="fs-4">1</p>
        <div class="bg-icon"><i class="fas fa-user-nurse"></i></div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="dashboard-card bhws">
        <h5>Total Health Workers</h5>
        <p class="fs-4">1</p>
        <div class="bg-icon"><i class="fas fa-hospital-user"></i></div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="dashboard-card patients">
        <h5>Total Patients</h5>
        <p class="fs-4">6</p>
        <div class="bg-icon"><i class="fas fa-user-injured"></i></div>
      </div>
    </div>
  </div>

  </div>

  <script src="<?php echo e(url('assets/js/script.js')); ?>"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>

  <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/index.blade.php ENDPATH**/ ?>