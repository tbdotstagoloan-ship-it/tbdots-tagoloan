<div class="sidebar">
      <div class="logo-container">
        <div class="logo">
          <img src="<?php echo e(asset('assets/img/tb00.png')); ?>" height="150" alt="">
        </div>
        <h2>Patient Monitoring System</h2>
      </div>
      <ul>
        <li>
          <a href="/">
            <i class="fas fa-home" style="margin-right: 10px"></i> Dashboard
          </a>
        </li>
        <li>
          <a href="<?php echo e(url('patient')); ?>">
            <i class="fas fa-users" style="margin-right: 10px"></i>
            Patient Record
          </a>
        </li>
        <li>
          <a href="<?php echo e(url('reports')); ?>">
            <i class="fas fa-chart-bar" style="margin-right: 10px"></i>
            Reports
          </a>
        </li>
        <li>
          <a href="<?php echo e(url('dashboard')); ?>">
            <i class="fas fa-sign-out-alt" style="margin-right: 10px"></i>
            Logout
          </a>
        </li>
      </ul>
    </div><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/sidebar.blade.php ENDPATH**/ ?>