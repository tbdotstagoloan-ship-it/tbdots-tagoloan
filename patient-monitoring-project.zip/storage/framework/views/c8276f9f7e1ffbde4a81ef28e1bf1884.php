<h3 class="mb-4"></h3>
  <div class="row g-4">
    <div class="col-md-3">
      <div class="card text-white bg-primary shadow-sm border-0">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-users me-2"></i> Total Patient</h5>
          <p class="card-text fs-4">1,245</p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-white bg-success shadow-sm border-0">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-user me-2"></i> Total Patient</h5>
          <p class="card-text fs-4">578</p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-white bg-secondary shadow-sm border-0">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-chart-bar me-2"></i> Total Patient</h5>
          <p class="card-text fs-4">63</p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-white bg-danger shadow-sm border-0">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-user-injured me-2"></i> Total Patient</h5>
          <p class="card-text fs-4">312</p>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/cards.blade.php ENDPATH**/ ?>