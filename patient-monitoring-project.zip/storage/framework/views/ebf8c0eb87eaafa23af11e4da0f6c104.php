<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>TB DOTS - Patient Lists</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
    <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
  </head>
  <body>
    <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('home/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patient')); ?>" class="nav-link">Patient List</a>
          </li>
          <li>
            <a href="<?php echo e(url('patientProfile')); ?>" class="nav-link">Patient Profile</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('medicalInformation')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Medical Information
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('adherenceTrackingData')); ?>">
           <span class="material-symbols-rounded">monitoring</span>
          Adherence Track Data
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Patient Health</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Adherence Report</a>
          </li>
          <li>
            <a href="<?php echo e(url('reports')); ?>" class="nav-link">Treatment Logs</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

    <div class="main-content">
      <h3 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600">
        Patient Lists
      </h3>

      <div class="d-flex justify-content-end mb-2">
        <a href="<?php echo e(url('form1')); ?>" class="btn add-product-btn btn-success">
          <i class="fas fa-plus me-2"></i>Add New Patient</a>
      </div>

      <div class="card inventory-card shadow-sm border-0">
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Full Name</th>
                  <th>Age</th>
                  <th>Address</th>
                  <th>Sex</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>0001</td>
                  <td>Janrey R. Cambe</td>
                  <td>31</td>
                  <td>Tagoloan, Misamis Oriental</td>
                  <td>Male</td>
                  <!-- <td><span class="badge bg-success">In Stock</span></td> -->
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>0002</td>
                  <td>Monita Rose Naguio</td>
                  <td>24</td>
                  <td>Cagayan de Oro City</td>
                  <td>Female</td>
                  <!-- <td><span class="badge bg-success">In Stock</span></td> -->
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>0003</td>
                  <td>Bernard B. Madjos</td>
                  <td>23</td>
                  <td>Cagayan de Oro City</td>
                  <td>Male</td>
                  <!-- <td><span class="badge bg-success">In Stock</span></td> -->
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>0004</td>
                  <td>Yancy Kent Maputol</td>
                  <td>23</td>
                  <td>Cagayan de Oro City</td>
                  <td>Male</td>
                  <!-- <td><span class="badge bg-warning text-dark">Low Stock</span></td> -->
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>0005</td>
                  <td>Syra Mae D. Alampayan</td>
                  <td>21</td>
                  <td>Misamis Oriental</td>
                  <td>Female</td>
                  <!-- <td><span class="badge bg-success">In Stock</span></td> -->
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
                <tr>
                  <td>0006</td>
                  <td>Lister Y. Solijon</td>
                  <td>21</td>
                  <td>Cagayan de Oro City</td>
                  <td>Male</td>
                  <!-- <td><span class="badge bg-success">In Stock</span></td> -->
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- The Modal -->
        <div class="modal fade" id="myModal">
          <div class="modal-dialog">
            <div class="modal-content">
              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">Patient Information</h4>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                ></button>
              </div>

              <!-- Modal body -->
              <div class="modal-body">
                <form action="" method="post">
                  <label for="name">Full Name</label>
                  <input type="text" name="name" id="name" class="form-control mt-2" placeholder="Full Name">
                  <label for="age">Age</label>
                  <input type="text" name="age" id="age" class="form-control mt-2" placeholder="Age">
                  <label for="address">Address</label>
                  <input type="text" name="address" id="address" class="form-control mt-2" placeholder="Address">
                  <label for="sex">Sex</label>
                  <input type="text" name="sex" id="sex" class="form-control mt-2" placeholder="Sex">
                </form>
              </div>

              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success me-2">Save Changes</button>
              </div>
            </div>
          </div>
        </div>

        <div class="card-footer">Showing 1 to 6 of 6 entries</div>
      </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/home/patient.blade.php ENDPATH**/ ?>