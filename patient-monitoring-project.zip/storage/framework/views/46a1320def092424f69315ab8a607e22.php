<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>TB DOTS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style1.css')); ?>" />
    <link rel="icon" href="<?php echo e(url('assets/img/lung-icon.png')); ?>">
  </head>

  <body>
    <div class="sidebar">
    <div class="logo-container">
      <div class="logo">
        <img src="<?php echo e(url('assets/img/TBDOTS.png')); ?>" height="150" alt="" />
      </div>
    </div>
    <ul class="accordion sidebar-menu" id="sidebarAccordion">
      <li>
        <a href="<?php echo e(url('admin/dashboard')); ?>">
          <span class="material-symbols-rounded">grid_view</span> 
          Dashboard
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('diagnosis')); ?>">
          <span class="material-symbols-rounded">medical_information</span>
          Diagnosis
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('notification')); ?>">
          <span class="material-symbols-rounded">notifications_active</span>
          Notification
        </a>
      </li>
      <li class="nav-item">
        <a href="#patientSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center patient-toggle collapsed">
          <span class="material-symbols-rounded">group</span>
          Patient
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="patientSubMenu">
          <li>
            <a href="<?php echo e(url('form/page1')); ?>" class="nav-link">Add Patient</a>
          </li>
          <li>
            <a href="<?php echo e(url('patiente')); ?>" class="nav-link">Patient List</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('treatment')); ?>">
           <span class="material-symbols-rounded">medical_services</span>
          Treatment
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('treatmentOutcome')); ?>">
           <span class="material-symbols-rounded">health_metrics</span>
          Treatment Outcome
        </a>
      </li>
      <li class="nav-item">
        <a href="#reportsSubMenu" data-bs-toggle="collapse" data-bs-parent="#sidebarAccordion"
          class="nav-link d-flex align-items-center reports-toggle collapsed">
           <span class="material-symbols-rounded">download</span>
          Generate Reports
          <i class="fas fa-chevron-right ms-auto toggle-arrow rotate-icon"></i>
        </a>
        <ul class="collapse list-unstyled ps-4" id="reportsSubMenu">
          <li>
            <a href="<?php echo e(url('feedback')); ?>" class="nav-link">Patient Feedback</a>
          </li>
          <li>
            <a href="<?php echo e(url('diagClassification')); ?>" class="nav-link">Patient Diagnosis</a>
          </li>
          <li>
            <a href="<?php echo e(url('notificationLog')); ?>" class="nav-link">Notification Log</a>
          </li>
          <li>
            <a href="<?php echo e(url('ongoingTreatments')); ?>" class="nav-link">Ongoing Treatment</a>
          </li>
          <li>
            <a href="<?php echo e(url('curedPatients')); ?>" class="nav-link">Cured Patients</a>
          </li>
          <li>
            <a href="<?php echo e(url('ltfuPatients')); ?>" class="nav-link">Lost to Follow-up</a>
          </li>
          <li>
            <a href="<?php echo e(url('failedPatients')); ?>" class="nav-link">Failed Treatments</a>
          </li>
          <li>
            <a href="<?php echo e(url('expiredPatients')); ?>" class="nav-link">Expired Patients</a>
          </li>
          <li>
            <a href="<?php echo e(url('intensiveTreatment')); ?>" class="nav-link">Intensive Treatment</a>
          </li>
          <li>
            <a href="<?php echo e(url('maintenanceTreatment')); ?>" class="nav-link">Maintenance Treatment</a>
          </li>
          <li>
            <a href="<?php echo e(url('barangayCases')); ?>" class="nav-link">Barangay Cases</a>
          </li>
          <li>
            <a href="<?php echo e(url('underagePatients')); ?>" class="nav-link">Underage Patients</a>
          </li>
          <li>
            <a href="<?php echo e(url('sputumLog')); ?>" class="nav-link">Sputum Log</a>
          </li>
          <li>
            <a href="<?php echo e(url('closeContact')); ?>" class="nav-link">Close Contact</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('profile')); ?>">
          <span class="material-symbols-rounded">settings</span> Settings
        </a>
      </li>
      <li>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
          <?php echo csrf_field(); ?>
          <button type="button" id="logout-btn" class="logout-button">
            <span class="material-symbols-rounded">logout</span>
            Logout
          </button>
        </form>
      </li>
    </ul>
  </div>

    <div class="main-content">
      <h3 style="margin-bottom: 20px; color: #2c3e50; font-weight: 600;">
        Sputum Summary Log from Patient and Diagnosis Record
      </h3>

      <div class="mb-2">
        <a href="<?php echo e(url('#')); ?>" class="btn icons btn-warning">
          <i class="fas fa-print me-1"></i> Print</a>
        <a href="<?php echo e(url('#')); ?>" class="btn icon btn-danger">
          <i class="fas fa-file-pdf me-1"></i> PDF</a>
      </div>
      
      <div class="card inventory-card shadow-sm border-0">
        <div class="card-body p-0">
          <div class="table-responsive">

                <table class="table">
              <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Age</th>
                  <th>Sex</th>
                  <th>Height</th>
                  <th>Weight</th>
                  <th>Sputum Test</th>
                  <th>Date Collected</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>

              <?php $__currentLoopData = $sputumLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                  <td><?php echo e($patient->pat_full_name); ?></td>
                  <td><?php echo e($patient->pat_age); ?></td>
                  <td><?php echo e($patient->pat_sex); ?></td>
                  <td><?php echo e($patient->pat_height); ?></td>
                  <td><?php echo e($patient->pat_weight); ?></td>
                  <td><?php echo e($patient->diag_sputum_test); ?></td>
                  <td><?php echo e($patient->diag_date_collected); ?></td>
                  <td class="text-center">
                  <div class="dropdown">
                    <button class="btn btn-light btn-sm rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <!-- <li>
                        <a class="dropdown-item" href="<?php echo e(url('patientProfile')); ?>">
                          <i class="fas fa-eye me-2"></i> View Details
                        </a>
                      </li> -->
                      <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#myModal">
                          <i class="fas fa-edit me-2"></i> Edit
                        </a>
                      </li>
                      <li>
                        <a class="dropdown-item" href="<?php echo e(url('error')); ?>">
                          <i class="fas fa-trash-alt me-2"></i> Delete
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
                </tr>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </tbody>
            </table>
  
                </div>
              </div>
            </div>
          </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(url('assets/js/logout.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/active.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\patient-monitoring-project\patient-monitoring-project\resources\views/reports/sputumLog.blade.php ENDPATH**/ ?>